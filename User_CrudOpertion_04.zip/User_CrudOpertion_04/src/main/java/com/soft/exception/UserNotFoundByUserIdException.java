package com.soft.exception;

public class UserNotFoundByUserIdException extends RuntimeException {

	public UserNotFoundByUserIdException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
