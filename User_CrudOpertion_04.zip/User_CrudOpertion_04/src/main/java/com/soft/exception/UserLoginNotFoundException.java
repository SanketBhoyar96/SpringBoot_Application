package com.soft.exception;

public class UserLoginNotFoundException extends RuntimeException {

	public UserLoginNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
