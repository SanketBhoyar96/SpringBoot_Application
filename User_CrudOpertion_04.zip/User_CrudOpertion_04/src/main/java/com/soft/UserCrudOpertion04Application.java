package com.soft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserCrudOpertion04Application {

	public static void main(String[] args) {
		SpringApplication.run(UserCrudOpertion04Application.class, args);
	}

}
