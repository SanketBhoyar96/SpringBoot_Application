package com.soft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserCrudOpertion04ApplicationTests {

	@Test
	void contextLoads() {
	}

}
