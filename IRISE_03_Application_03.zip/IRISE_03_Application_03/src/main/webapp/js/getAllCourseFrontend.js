/**
 * 
 */

$(document).ready(function() {
		//alert("msg")
		findAllCourse();
		findCourseById();
});


 
 function findAllCourse() {

	var settings = {
		"url": "/course/getAllcourse",
		"method": "GET",
		"timeout": 0,
	};

	$.ajax(settings).done(function(response) {
		console.log(response);

		response.forEach(function(obj, index) {

			$('#showCourseAll').append('<div id="box"><img src="https://ashokitech.com/uploads/course/python-fullstack-online-training.jpeg" alt=""" width="296px" height="170px"><span>ID::<i>' + obj.courseId + '</i></span><br><span>CourseName::<i>'
				+ obj.courseName + '</i></span><br><span>Duration::<i>'
				+ obj.duration + 'Months</i></span><br><i>Fees::<b>'
				+ obj.fees + '</b></i><br><button onclick="preview(' + obj.courseId + ')"><i class="fa-solid fa-magnifying-glass"></i>Preview</button><button style="background-color: red; border:none;" onclick="viewDetails(' + obj.courseId + ')"><i class="fa-regular fa-eye"></i>View Details</button></div>')

		});
	});

}


function viewDetails(courseId) {
	window.location = "/viewCourses?courseId=" + courseId;
}

function findCourseById() {

	var url = window.location.href;
	var splitter = url.split('=');
	var courseId = splitter[1];

	var settings = {
		"url": "/course/findbyId?courseId=" + courseId,
		"method": "GET",
		"timeout": 0,
	};

	$.ajax(settings).done(function(response) {
		console.log(response);

		if (response != null) {
			//alert("work")
			$('#courseid').val(response.courseId);
			$('#coursename').val(response.courseName);
			$('#duration').val(response.duration);
			$('#fees').val(response.fees);

		} else {
			window.location = "/";
		}

	});
}

