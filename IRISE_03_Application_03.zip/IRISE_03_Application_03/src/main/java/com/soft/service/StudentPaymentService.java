package com.soft.service;

import java.util.HashMap;

import com.soft.model.StudentPayment;

public interface StudentPaymentService {
	
	public HashMap<String,Object> savedPayemntService(StudentPayment studentPayment);

}
