package com.soft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Irise03Application03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
