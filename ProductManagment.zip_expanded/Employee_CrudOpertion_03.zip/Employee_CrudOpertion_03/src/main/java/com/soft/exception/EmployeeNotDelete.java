package com.soft.exception;

public class EmployeeNotDelete extends RuntimeException {

	public EmployeeNotDelete(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
